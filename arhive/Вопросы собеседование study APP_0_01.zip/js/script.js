import { send } from "../js/data.js";

console.log("Start app =>");

const answers = document.getElementById("answers");
const buttonSubmit = document.getElementById("submit");
const buttonUpdate = document.getElementById("update");
const question = document.getElementById("question");
const a_text = document.getElementById("a_text");
const tags = document.getElementById("tags");

question.innerHTML = send[0].question;
a_text.innerHTML = send[0].answer;
tags.innerHTML = "#" + send[0].tags;

buttonSubmit.addEventListener("click", function () {
  console.log("Кнопка submit нажата.");
  answers.classList.toggle("answers-none");

  buttonSubmit.innerHTML =
    buttonSubmit.innerHTML === "Показать ОТВЕТ"
      ? (buttonSubmit.innerHTML = "Скрыть ОТВЕТ")
      : (buttonSubmit.innerHTML = "Показать ОТВЕТ");
});

let ransArray = [];
for (let i = 0; i < send.length; i++) {
  ransArray.push(i);
}
console.log("ransArray ", ransArray);

buttonUpdate.addEventListener("click", function () {
  let rand = Math.floor(Math.random() * (send.length - 1));

  while (rand == 0 || rand == send.length) {
    rand = Math.floor(Math.random() * (send.length - 1 + send.length - 1));
  }

  console.log("Кнопка update нажата. ", rand);
  if (!answers.classList.contains("answers-none")) {
    answers.classList.add("answers-none");
  }

  question.innerHTML = send[rand].question;
  a_text.innerHTML = send[rand].answer;
  tags.innerHTML = "#" + send[rand].tags;

  buttonSubmit.innerHTML =
    buttonSubmit.innerHTML === "Скрыть ОТВЕТ"
      ? (buttonSubmit.innerHTML = "Показать ОТВЕТ")
      : (buttonSubmit.innerHTML = "Показать ОТВЕТ");
});
